# Nude Aura – Website Project
**Module:** WEDE5020 – Web Development (Introduction)  
**Student:** ST10537202  
**Assessment:** Portfolio of Evidence (PoE) – Part 1

---

## Project Overview
Nude Aura is a premium inclusive beauty and cosmetics e-commerce brand website. The site is designed to serve individuals aged 16–35 who are interested in skincare, makeup, and self-care. The brand is inclusive and caters to all gender identities, promoting diversity in the beauty industry.

---

## Website Goals and Objectives
- Create an effective online presence enabling customers to browse and purchase products
- Grow brand awareness and drive online sales
- Promote inclusivity and diversity within the beauty industry
- Provide a user-friendly, accessible, and responsive platform

---

## Key Features and Functionality
- Fully responsive design (desktop, tablet, mobile)
- Product search and filter functionality (JavaScript)
- FAQ accordion (JavaScript)
- Product enquiry form with client-side validation and dynamic response
- Contact form with client-side validation and mailto integration
- Add-to-cart notifications
- Newsletter subscription form
- Back-to-top button
- Sticky navigation header with mobile hamburger menu
- SEO meta tags on all pages

---

## File and Folder Structure
```
nude-aura/
├── index.html          # Homepage
├── about.html          # About Us page
├── products.html       # Shop / Products page
├── enquiry.html        # Product Enquiry page
├── contact.html        # Contact page
├── css/
│   └── style.css       # External stylesheet (responsive, CSS variables)
├── js/
│   └── main.js         # JavaScript (validation, interactions, FAQ, filter)
├── images/             # (Images folder – to be populated)
└── README.md           # This file
```

---

## Timeline and Milestones
| Milestone         | Target Date  |
|-------------------|-------------|
| Part 1 – Foundation (HTML + Planning) | Week 4  |
| Part 2 – CSS Styling & Responsive Design | Week 8  |
| Part 3 – JavaScript & SEO             | Week 12 |

---

## Technologies Used
- HTML5 (semantic elements: header, nav, main, section, footer, article)
- CSS3 (Flexbox, Grid, CSS custom properties, media queries, animations)
- JavaScript (ES6+, DOM manipulation, form validation, AJAX-ready)
- Google Fonts (Playfair Display, Lato)

---

## Part 1 Details
### Completed:
- Defined target organisation (Nude Aura – online beauty & cosmetics)
- Website Project Proposal submitted
- 5 HTML pages created with semantic structure
- Navigation linking all pages
- External CSS stylesheet applied
- External JavaScript file implemented
- Basic HTML content integrated (headings, paragraphs, lists, links)
- Responsive design with mobile hamburger menu
- Forms on enquiry.html and contact.html with client-side validation

### Pages Created:
1. **index.html** – Homepage with hero, features, products, testimonials
2. **about.html** – About Us, mission/vision, team
3. **products.html** – Full product catalogue with search/filter
4. **enquiry.html** – Product enquiry form with dynamic response
5. **contact.html** – Contact form, two office locations, map placeholders

---

## Changelog

### v1.0.0 – Part 1 Submission
- Initial project structure created
- All 5 HTML pages built with semantic HTML5
- CSS stylesheet created with CSS custom properties and responsive design
- JavaScript file created with form validation, FAQ accordion, search/filter, cart notifications
- README.md initialised

---

## References
Easey, M. (2019) *Fashion Marketing*. 4th edn. Oxford: Wiley-Blackwell.

Forbes (2023) *Beauty industry trends and growth*. Available at: https://www.forbes.com (Accessed: 2025).

Google Fonts (2025) *Playfair Display & Lato typefaces*. Available at: https://fonts.google.com (Accessed: 2025).

MDN Web Docs (2025) *HTML: HyperText Markup Language*. Available at: https://developer.mozilla.org (Accessed: 2025).

MDN Web Docs (2025) *CSS: Cascading Style Sheets*. Available at: https://developer.mozilla.org (Accessed: 2025).

Shopify (2023) *How to start a beauty business online*. Available at: https://www.shopify.com (Accessed: 2025).

Statista (2024) *Online fashion market statistics*. Available at: https://www.statista.com (Accessed: 2025).

W3Schools (2025) *JavaScript Tutorial*. Available at: https://www.w3schools.com (Accessed: 2025).
