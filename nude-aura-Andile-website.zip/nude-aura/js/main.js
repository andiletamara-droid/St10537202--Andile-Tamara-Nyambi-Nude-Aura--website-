/**
 * NUDE AURA - Main JavaScript
 * Author: ST10537202
 * Module: WEDE5020
 */

/* ============================================
   HAMBURGER MENU
   ============================================ */
document.addEventListener('DOMContentLoaded', function () {

  const hamburger = document.getElementById('hamburger');
  const navLinks  = document.getElementById('nav-links');

  if (hamburger && navLinks) {
    hamburger.addEventListener('click', function () {
      navLinks.classList.toggle('open');
      const isOpen = navLinks.classList.contains('open');
      hamburger.setAttribute('aria-expanded', isOpen);
    });

    // Close nav when a link is clicked (mobile)
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => navLinks.classList.remove('open'));
    });
  }

  /* ============================================
     BACK TO TOP BUTTON
     ============================================ */
  const backToTop = document.getElementById('back-to-top');
  if (backToTop) {
    window.addEventListener('scroll', function () {
      backToTop.classList.toggle('visible', window.scrollY > 400);
    });
    backToTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ============================================
     FAQ ACCORDION
     ============================================ */
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', function () {
      const item = this.closest('.faq-item');
      const isOpen = item.classList.contains('open');
      // Close all
      document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      // Toggle current
      if (!isOpen) item.classList.add('open');
    });
  });

  /* ============================================
     CONTACT FORM VALIDATION
     ============================================ */
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      let valid = true;

      // Clear previous errors
      contactForm.querySelectorAll('.form-error').forEach(el => el.classList.remove('visible'));
      contactForm.querySelectorAll('input, textarea, select').forEach(el => el.classList.remove('error'));

      const name    = document.getElementById('contact-name');
      const email   = document.getElementById('contact-email');
      const phone   = document.getElementById('contact-phone');
      const message = document.getElementById('contact-message');

      // Name validation
      if (!name.value.trim() || name.value.trim().length < 2) {
        showError(name, 'contact-name-error', 'Please enter your full name (min 2 characters).');
        valid = false;
      }

      // Email validation
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email.value.trim())) {
        showError(email, 'contact-email-error', 'Please enter a valid email address.');
        valid = false;
      }

      // Phone validation (optional but must be valid if filled)
      if (phone && phone.value.trim()) {
        const phonePattern = /^[0-9+\s\-()]{7,15}$/;
        if (!phonePattern.test(phone.value.trim())) {
          showError(phone, 'contact-phone-error', 'Please enter a valid phone number.');
          valid = false;
        }
      }

      // Message validation
      if (!message.value.trim() || message.value.trim().length < 10) {
        showError(message, 'contact-message-error', 'Message must be at least 10 characters.');
        valid = false;
      }

      if (valid) {
        // Build email body and open mailto
        const body = `Name: ${name.value}\nEmail: ${email.value}\nPhone: ${phone ? phone.value : 'N/A'}\n\nMessage:\n${message.value}`;
        const mailTo = `mailto:info@nudeaura.co.za?subject=Contact%20Form%20Message&body=${encodeURIComponent(body)}`;
        window.location.href = mailTo;

        // Show success
        const successMsg = document.getElementById('contact-success');
        if (successMsg) {
          successMsg.style.display = 'block';
          contactForm.reset();
        }
      }
    });
  }

  /* ============================================
     ENQUIRY FORM VALIDATION & RESPONSE
     ============================================ */
  const enquiryForm = document.getElementById('enquiry-form');
  if (enquiryForm) {
    enquiryForm.addEventListener('submit', function (e) {
      e.preventDefault();
      let valid = true;

      enquiryForm.querySelectorAll('.form-error').forEach(el => el.classList.remove('visible'));
      enquiryForm.querySelectorAll('input, textarea, select').forEach(el => el.classList.remove('error'));

      const eName     = document.getElementById('enquiry-name');
      const eEmail    = document.getElementById('enquiry-email');
      const eProduct  = document.getElementById('enquiry-product');
      const eMessage  = document.getElementById('enquiry-message');

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!eName.value.trim()) {
        showError(eName, 'enquiry-name-error', 'Name is required.');
        valid = false;
      }
      if (!emailPattern.test(eEmail.value.trim())) {
        showError(eEmail, 'enquiry-email-error', 'Please enter a valid email address.');
        valid = false;
      }
      if (!eProduct.value) {
        showError(eProduct, 'enquiry-product-error', 'Please select a product category.');
        valid = false;
      }
      if (!eMessage.value.trim() || eMessage.value.trim().length < 10) {
        showError(eMessage, 'enquiry-message-error', 'Please provide more detail (min 10 characters).');
        valid = false;
      }

      if (valid) {
        // Show simulated response
        const result = document.getElementById('enquiry-result');
        if (result) {
          const productNames = {
            skincare: 'Skincare',
            makeup: 'Makeup & Colour',
            haircare: 'Hair Care',
            fragrance: 'Fragrances',
            wellness: 'Wellness & Body',
          };
          const selectedProduct = productNames[eProduct.value] || eProduct.value;
          result.innerHTML = `
            <h4 style="font-family:var(--font-display);color:var(--deep-rose);margin-bottom:0.5rem">
              ✅ Thank you, ${eName.value.split(' ')[0]}!
            </h4>
            <p>We've received your enquiry about <strong>${selectedProduct}</strong>.</p>
            <p>A representative will contact you at <strong>${eEmail.value}</strong> within 1–2 business days with pricing, availability, and personalised product recommendations.</p>
            <p style="margin-top:0.8rem;font-size:0.85rem;color:var(--mid-grey)">Reference: #NA${Date.now().toString().slice(-6)}</p>
          `;
          result.style.display = 'block';
          result.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          enquiryForm.reset();
        }
      }
    });
  }

  /* ============================================
     SHOP SEARCH & FILTER
     ============================================ */
  const searchInput    = document.getElementById('product-search');
  const categoryFilter = document.getElementById('category-filter');

  if (searchInput || categoryFilter) {
    function filterProducts() {
      const query    = searchInput ? searchInput.value.toLowerCase() : '';
      const category = categoryFilter ? categoryFilter.value : '';
      const cards    = document.querySelectorAll('.product-card');

      cards.forEach(card => {
        const name     = (card.dataset.name    || '').toLowerCase();
        const catData  = (card.dataset.category || '').toLowerCase();
        const matchQ   = !query    || name.includes(query);
        const matchC   = !category || catData === category;
        card.style.display = (matchQ && matchC) ? '' : 'none';
      });
    }

    if (searchInput)    searchInput.addEventListener('input', filterProducts);
    if (categoryFilter) categoryFilter.addEventListener('change', filterProducts);
  }

  /* ============================================
     ADD TO CART NOTIFICATION
     ============================================ */
  document.querySelectorAll('.btn-add-cart').forEach(btn => {
    btn.addEventListener('click', function () {
      const card    = this.closest('.product-card');
      const name    = card ? card.dataset.name || 'Product' : 'Product';
      const counter = document.getElementById('cart-count');
      if (counter) {
        const current = parseInt(counter.textContent) || 0;
        counter.textContent = current + 1;
        counter.style.display = 'inline';
      }

      // Button feedback
      const original = this.textContent;
      this.textContent = '✓ Added!';
      this.style.background = '#27ae60';
      setTimeout(() => {
        this.textContent = original;
        this.style.background = '';
      }, 1500);
    });
  });

  /* ============================================
     WISHLIST TOGGLE
     ============================================ */
  document.querySelectorAll('.btn-wishlist').forEach(btn => {
    btn.addEventListener('click', function () {
      const active = this.dataset.active === 'true';
      this.dataset.active = active ? 'false' : 'true';
      this.textContent    = active ? '♡ Save' : '♥ Saved';
      this.style.color    = active ? '' : '#C2737A';
    });
  });

  /* ============================================
     NEWSLETTER FORM
     ============================================ */
  const newsletterForm = document.getElementById('newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const input = this.querySelector('input[type="email"]');
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!input || !emailPattern.test(input.value.trim())) {
        alert('Please enter a valid email address.');
        return;
      }
      const btn = this.querySelector('button');
      btn.textContent = '✓ Subscribed!';
      btn.style.background = '#27ae60';
      input.value = '';
    });
  }

  /* ============================================
     ACTIVE NAV LINK
     ============================================ */
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(link => {
    if (link.getAttribute('href') === currentPage) {
      link.classList.add('active');
    }
  });

});

/* ============================================
   HELPER: SHOW FORM ERROR
   ============================================ */
function showError(field, errorId, message) {
  field.classList.add('error');
  const errEl = document.getElementById(errorId);
  if (errEl) {
    errEl.textContent = message;
    errEl.classList.add('visible');
  }
}
